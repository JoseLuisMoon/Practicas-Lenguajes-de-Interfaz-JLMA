; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 10. Obtención de una cadena decimal
; Descripción: Calcula el estado de transferencia de un archivo de 100,000 bytes (125 bloques de 512 bytes) obteniendo bytes descargados, pendientes, paquetes de 1024 con su residuo y porcentaje, transformando cada cifra a texto ASCII mediante una subrutina propia para su despliegue con WriteString.

INCLUDE Irvine32.inc

.data
	; Rótulos para la presentación de los resultados en pantalla
	msgInicio BYTE "Avance de la descarga:", 0 
	msgBytesDescargados BYTE "Bytes descargados: ", 0 
	msgBytesPendientes BYTE "Bytes pendientes: ", 0
	msgGruposCompletos BYTE "Grupos completos de 1024 bytes: ", 0 
	msgResiduo BYTE "Residuo de los agrupamientos: ", 0 
	msgPorcentaje BYTE "Porcentaje de avance de la descarga: ", 0

	; Variables para almacenar los valores numéricos calculados
	bytesDescargados DWORD ? 
	bytesPendientes DWORD ?
	gruposCompletos DWORD ? 
	residuo DWORD ? 
	porcentajeDescarga DWORD ? 

	bufferConversion BYTE 11 DUP(0) ; Búfer de 11 bytes para armar las cadenas de texto ASCII

.code
main PROC

	; 1. Cálculo de bytes descargados (125 bloques de 512 bytes)
	mov eax, 125 ; Número de bloques
	mov ebx, 512 ; Tamaño de cada bloque
	mul ebx ; Multiplica 125 * 512
	mov bytesDescargados, eax ; Almacena el total de bytes recibidos

	; 2. Cálculo de bytes pendientes (100000 - bytes descargados)
	mov eax, 100000 ; Tamaño total del archivo
	sub eax, bytesDescargados ; Resta directamente los bytes ya descargados
	mov bytesPendientes, eax ; Guarda el restante por transferir

	; 3. Cálculo de paquetes de 1024 bytes y su sobrante
	mov eax, bytesDescargados ; Carga los bytes descargados
	mov edx, 0 ; Limpia la parte alta EDX antes de dividir
	mov ebx, 1024 ; Divisor de 1024 bytes
	div ebx ; Divide EDX:EAX entre 1024
	mov gruposCompletos, eax ; Guarda los paquetes enteros resultantes (cociente)
	mov residuo, edx ; Guarda los bytes restantes que no completaron bloque (residuo)

	; 4. Cálculo del porcentaje de avance (descargados * 100 / 100000)
	mov eax, bytesDescargados ; Carga los bytes descargados
	mov ebx, 100 ; Multiplicador de escala a porcentaje
	mul ebx ; Multiplica descargados por 100
	mov ebx, 100000 ; Divisor con el total del archivo
	div ebx ; Divide para obtener el porcentaje entero
	mov porcentajeDescarga, eax ; Guarda el porcentaje calculado

	; PRESENTACIÓN DE RESULTADOS POR CONSOLA
	mov edx, OFFSET msgInicio
	call WriteString
	call Crlf
	call Crlf

	; Despliegue de bytes descargados
	mov edx, OFFSET msgBytesDescargados
	call WriteString 
	mov eax, bytesDescargados
	mov esi, OFFSET bufferConversion
	call convertirDecimal
	mov edx, OFFSET bufferConversion
	call WriteString
	call Crlf

	; Despliegue de bytes pendientes
	mov edx, OFFSET msgBytesPendientes
	call WriteString 
	mov eax, bytesPendientes
	mov esi, OFFSET bufferConversion
	call convertirDecimal
	mov edx, OFFSET bufferConversion
	call WriteString
	call Crlf 

	; Despliegue de grupos completos de 1024 bytes
	mov edx, OFFSET msgGruposCompletos
	call WriteString
	mov eax, gruposCompletos
	mov esi, OFFSET bufferConversion
	call convertirDecimal
	mov edx, OFFSET bufferConversion 
	call WriteString 
	call Crlf

	; Despliegue del residuo de los grupos
	mov edx, OFFSET msgResiduo
	call WriteString
	mov eax, residuo
	mov esi, OFFSET bufferConversion
	call convertirDecimal
	mov edx, OFFSET bufferConversion
	call WriteString
	call Crlf 

	; Despliegue del porcentaje
	mov edx, OFFSET msgPorcentaje
	call WriteString
	mov eax, porcentajeDescarga
	mov esi, OFFSET bufferConversion
	call convertirDecimal
	mov edx, OFFSET bufferConversion
	call WriteString
	call Crlf

	exit
main ENDP

convertirDecimal PROC ; Convierte el valor en EAX a caracteres ASCII en el búfer apuntado por ESI

	; Guarda el estado de los registros en la pila
	push eax
	push ebx 
	push ecx 
	push edx
	push esi 

	mov ecx, 0 ; Inicializa el contador de dígitos en 0

extraer_digitos:
	mov edx, 0 ; Limpia EDX para la división
	mov ebx, 10 ; Base diez para aislar el último dígito
	div ebx ; Divide EDX:EAX entre 10 (cociente en EAX, residuo en EDX)
	push edx ; Guarda el residuo (dígito extraído) en la pila
	inc ecx ; Cuenta un dígito más
	cmp eax, 0 ; Verifica si todavía quedan cifras
	jne extraer_digitos ; Si el cociente no es cero, continúa dividiendo

construir_cadena:
	pop edx ; Saca el dígito de la pila en orden correcto (LIFO)
	mov bl, dl ; Pasa el residuo a BL
	add bl, '0' ; Convierte el dígito numérico a su código ASCII
	mov [esi], bl ; Escribe el carácter en la posición del búfer
	inc esi ; Avanza a la siguiente posición de memoria
	loop construir_cadena ; Repite para todos los dígitos desapilados

	mov byte ptr [esi], 0 ; Agrega el terminador nulo al final de la cadena

	; Restaura los registros guardados en la pila
	pop esi
	pop edx
	pop ecx
	pop ebx
	pop eax
	ret ; Regresa al punto de llamada
convertirDecimal ENDP

END main