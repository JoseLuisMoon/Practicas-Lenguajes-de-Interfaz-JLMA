; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 13. Obtención de una cadena hexadecimal
; Descripción: Convierte un valor numérico de 32 bits a texto hexadecimal extrayendo cada nibble con una máscara 0Fh, traduciendo de 0-9 o A-F con saltos condicionales y guardando de derecha a izquierda en un búfer.
INCLUDE Irvine32.inc
.data

; Cadenas empleadas para presentar el dato inicial y el resultado convertido
msgHexadecimal BYTE "Numero hexadecimal: 12AB34CD", 0
msgResultado   BYTE "Cadena obtenida: ", 0 

; Arreglo de 9 bytes que albergará los 8 caracteres hexadecimales y el carácter nulo final
bufferHex BYTE 9 DUP(0)

.code 
main PROC 

	mov edx, OFFSET msgHexadecimal ; Muestra el valor original en base 16
	call WriteString
	call Crlf ; Genera una nueva línea

	mov eax, 12AB34CDh ; Carga el valor numérico de 32 bits a transformar 
	mov esi, 7 ; Sitúa el índice en la última celda del búfer (posición 7)
	mov ecx, 8 ; Contador de 8 repeticiones para los 8 dígitos hexadecimales

convertir:
	mov dl, al ; Copia los 8 bits inferiores a DL para trabajar el dígito
	and dl, 0Fh ; Aplica la máscara 0Fh para aislar el nibble bajo

	cmp dl, 9 ; Compara el valor del nibble con 9
	ja esLetra ; Si es mayor que 9 (valores 10 a 15), salta para convertir a letra 'A'-'F'

	; Caso de dígitos numéricos (0 a 9)
	add dl, '0' ; Suma '0' para obtener el código ASCII del dígito
	jmp guardarDigito ; Salta a escribir el carácter en memoria

esLetra:
	; Caso de letras hexadecimales (10 a 15)
	sub dl, 10 ; Resta 10 para calcular la posición relativa
	add dl, 'A' ; Suma el código base de 'A' para obtener el carácter entre 'A' y 'F'

guardarDigito:
	mov bufferHex[esi], dl ; Asienta el carácter ASCII en el búfer
	shr eax, 4 ; Desplaza EAX 4 bits a la derecha para preparar el siguiente nibble
	dec esi ; Retrocede el puntero para llenar de derecha a izquierda
	loop convertir ; Repite el ciclo hasta procesar los 8 dígitos

	mov edx, OFFSET msgResultado ; Presenta el rótulo del resultado
	call WriteString
	mov edx, OFFSET bufferHex ; Carga la dirección de la cadena hexadecimal obtenida
	call WriteString ; Imprime la cadena de texto en consola
	call Crlf 

	exit

main ENDP

END main
