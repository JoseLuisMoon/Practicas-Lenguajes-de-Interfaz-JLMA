; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: Comparación y prueba.
; Descripción: Demuestra el comportamiento de las instrucciones CMP y TEST inspeccionando los cambios que provocan en las banderas ZF, SF, CF y OF.

INCLUDE Irvine32.inc


.code
main PROC
	
	; PRUEBA 1: BANDERA DE CERO (ZF)
	; El flag ZF se pone en 1 cuando la comparación u operación da como resultado un valor nulo (cero).
	mov eax, 10
	mov ebx, 10

	cmp eax, ebx ; Resta interna sin alterar operandos; al ser iguales produce cero y enciende ZF
	call DumpRegs ; Imprime los valores presentes en registros y el estado de las banderas

	mov eax, 10h ; Carga del valor hexadecimal 10h (equivalente a 16 decimal)
	mov ebx, 10h
	cmp eax, 10h ; Coteja EAX frente a 10h; al coincidir se levanta la bandera ZF

	call DumpRegs
	
	mov eax, 0 ; Restablece a cero el registro EAX
	mov al, 000000101b ; Coloca el patrón binario 0101b (5 en base decimal) en el subregistro AL
	cmp al, 5 ; Confronta con 5 decimal, generando cero en la resta y activando ZF

	call DumpRegs

	; PRUEBA 2: BANDERA DE SIGNO (SF)
	; La bandera SF se enciende cuando el valor resultante posee signo negativo (bit más significativo en 1).
	mov eax, 3
	mov ebx, 4
	cmp eax, ebx ; Resta conceptual 3 - 4 con resultado negativo, lo cual activa SF

	call DumpRegs

	mov eax, 0
	mov ebx, 0 ; Reinicialización de ambos registros a cero

	mov al, -5 ; Carga el número negativo -5 en AL
	mov bl, 1 ; Asigna el valor 1 a BL
	cmp al, bl ; Compara -5 con 1; el resultado de la sustracción es negativo y enciende SF

	call DumpRegs

	; PRUEBA 3: BANDERA DE ACARREO (CF)
	; La bandera CF se activa si una operación aritmética sin signo precisa un préstamo o acarreo.
	mov eax, 0
	mov ebx, 0

	mov al, 5 ; Asigna 5 al subregistro AL
	mov bl, 10 ; Asigna 10 al subregistro BL
	cmp al, bl ; Al ser el minuendo menor que el sustraendo (5 < 10), se requiere préstamo y se activa CF

	call DumpRegs

	; PRUEBA 4: DESBORDAMIENTO (OF)
	; La bandera OF indica que un cómputo con signo ha rebasado el rango representable del registro.
	mov eax, 0
	mov ebx, 0

	mov al, -128 ; Asigna -128 a AL, correspondiente al valor mínimo para un entero con signo de 8 bits
	mov bl, 1 ; Carga 1 en BL
	cmp al, bl ; Al restar 1 a -128 se obtiene -129, fuera del intervalo [-128, 127], disparando OF

	call DumpRegs

	; PRUEBA 5: INSTRUCCIÓN TEST
	; Efectúa una conjunción lógica AND bit a bit sin alterar los registros destino, actualizando únicamente EFLAGS.
	mov eax, 0

	mov al, 5 ; Carga 5 (00000101b) en AL
	test  al, 1 ; Aplica AND con 00000001b para examinar si el bit menos significativo está activo

	call DumpRegs

	 
	mov al, 10000000b ; Carga 10000000b en AL, donde el bit más significativo (MSB) es 1
	test al, 10000000b ; Comprueba el bit 7; al resultar el bit en 1, el procesador interpreta un valor negativo y enciende SF
	; ¿Por qué se prende Sign Flag? Porque el bit 7 (el más representativo a la izquierda) vale 1, lo cual denota signo negativo y dispara la bandera SF.

	call DumpRegs 

	exit
main ENDP
END main