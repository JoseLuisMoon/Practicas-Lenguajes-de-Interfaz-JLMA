; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 12. Desplazamiento y rotación
; Descripción: Explica detalladamente las operaciones a nivel de bit para desplazamientos lógicos y aritméticos (SHL, SHR, SAR) y rotaciones simples o con acarreo (ROL, ROR, RCL, RCR), manejando desplazamientos por constante y mediante el registro CL.
INCLUDE Irvine32.inc

.code 
main PROC 
	mov eax, 0        ; Reinicia el acumulador EAX

	; 1 - SHL: CORRIMIENTO LÓGICO A LA IZQUIERDA
	; Corre los bits hacia la izquierda introduciendo ceros por la derecha; el bit desplazado pasa a la bandera CF
	mov al, 00000110b ; Carga en AL el patrón 00000110b (6 en decimal)
	shl al, 1         ; Efectúa un corrimiento de un bit a la izquierda (equivale a multiplicar por 2)
	
	call DumpRegs     ; Vuelca en pantalla el contenido de registros y banderas
	call WriteBin     ; Presenta en consola la secuencia de bits resultante
	call Crlf         ; Salto de línea

	; 2 - SHR: CORRIMIENTO LÓGICO A LA DERECHA
	; Desplaza la secuencia a la derecha insertando ceros a la izquierda para datos no signados
	mov al, 00001100b ; Asigna 00001100b a AL (12 en decimal)
	shr al, 1         ; Corre los bits un lugar a la derecha (equivale a dividir por 2 sin signo)
	
	call DumpRegs     ; Muestra el estado de los registros actualizados
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 3 - SAR: CORRIMIENTO ARITMÉTICO A LA DERECHA (CON SIGNO)
	; Desplaza los bits a la derecha replicando el bit de signo (MSB) para mantener el signo negativo
	mov al, -8        ; Introduce el entero signado -8 en AL
	sar al, 1         ; Corre un bit a la derecha preservando el signo (división de -8 entre 2)
	
	call DumpRegs     ; Muestra el estado de los registros y banderas
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 4 - CORRIMIENTO CON VALOR INMEDIATO CONSTANTE
	; Especifica directamente en la instrucción la cantidad de posiciones a desplazar
	mov al, 00001100b ; Inicializa AL con el binario 00001100b (12 decimal)
	shl al, 2         ; Desplaza dos lugares a la izquierda (multiplica por 4)

	call DumpRegs     ; Muestra el estado de los registros y banderas
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 5 - CORRIMIENTO VARIABLE CONTROLADO POR EL REGISTRO CL
	; Emplea el subregistro CL como parámetro contador para la cantidad de desplazamientos
	mov al, 00010100b ; Carga el valor 00010100b (20 en base diez)
	mov cl, 2         ; Establece en CL el número de desplazamientos (2)
	shr al, cl        ; Desplaza AL a la derecha la cantidad contenida en CL

	call DumpRegs     ; Muestra el estado de los registros y banderas
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 6 - ROL: ROTACIÓN HACIA LA IZQUIERDA SIN ACARREO
	; 6 - ROL: ROTACIÓN HACIA LA IZQUIERDA SIN ACARREO
	; Los bits que salen por el extremo izquierdo recirculan entrando por la derecha
	mov al, 00000011b ; Carga el valor binario 00000011b (3 decimal)
	rol al, 1         ; Rota 1 bit a la izquierda: el bit 7 pasa al bit 0 y a la bandera CF
	
	call DumpRegs     ; Muestra el estado de los registros y banderas (AL = 00000110b, CF = 0)
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 7 - ROR: ROTACIÓN HACIA LA DERECHA SIN ACARREO
	; Los bits que salen por el extremo derecho vuelven a entrar por el extremo izquierdo
	mov al, 11000000b ; Carga el valor binario 11000000b (C0h)
	ror al, 1         ; Rota 1 bit a la derecha: el bit 0 pasa al bit 7 y a la bandera CF
	
	call DumpRegs     ; Muestra el estado de los registros y banderas (AL = 01100000b, CF = 0)
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 8 - RCL: ROTACIÓN A LA IZQUIERDA CON ACARREO
	; El bit más significativo (bit 7) pasa a la bandera CF, y el valor previo de CF entra por el bit 0
	mov al, 10100000b ; Carga un patrón con el bit 7 en 1
	rcl al, 1         ; Rota a la izquierda pasando el bit 7 a CF y metiendo el acarreo previo por la derecha
	
	call DumpRegs     ; Muestra el estado de los registros (CF = 1)
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	; 9 - RCR: ROTACIÓN A LA DERECHA CON ACARREO
	; El bit menos significativo (bit 0) pasa a CF, y el valor previo de CF entra por el bit 7
	mov al, 00000101b ; Carga un patrón con el bit 0 en 1
	rcr al, 1         ; Rota a la derecha pasando el bit 0 a CF y metiendo el acarreo previo por el bit 7
	
	call DumpRegs     ; Muestra el estado de los registros (CF = 1)
	call WriteBin     ; Muestra el resultado binario
	call Crlf

	exit

main ENDP

END main