; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 5.1. Repetir hasta que el usuario ingrese cero.
; Descripción: Solicita números enteros de forma repetitiva y los muestra en consola hasta que se introduce un 0 para finalizar el ciclo.
INCLUDE Irvine32.inc
.data
    msgIngresar  BYTE "Ingrese un numero (en caso de querer terminar el programa ingresar 0): ", 0
    msgFinal   BYTE "El programa ha finalizado al ingresar 0", 0
.code
main PROC

ciclo:
    mov edx, OFFSET msgIngresar ; Presenta la solicitud de captura en pantalla
    call WriteString 
    call ReadInt ; Lee el número tecleado por el usuario y lo almacena en EAX

    cmp eax, 0 ; Compara directamente el valor ingresado con cero
    je terminar ; Si el usuario ingresó cero, sale de la repetición hacia terminar

    call WriteInt ; Si no fue cero, imprime el número recibido (contenido en EAX)
    call Crlf ; Salto de línea después de imprimir
    jmp ciclo ; Regresa de manera incondicional al inicio del ciclo para pedir otro valor

terminar:
    mov edx, OFFSET msgFinal ; Carga y muestra la notificación de cierre del programa
    call WriteString
    call Crlf

    exit
main ENDP

END main