; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 9. PUSH y POP
; Descripción: Explica el mecanismo de la pila del sistema (Stack) con PUSH y POP bajo la disciplina LIFO, además de ilustrar el respaldo de registros y el uso de subrutinas con CALL y RET.
INCLUDE Irvine32.inc

.code
main PROC

	; SECCIÓN 1: OPERACIONES ELEMENTALES DE PUSH Y POP
	mov eax, 20 ; Asigna el número 20 en base decimal al registro EAX

	push eax ; Almacena EAX en la pila, lo que reduce el puntero ESP en 4 bytes

	nop ; Pausa para comprobación de registros y de la pila

	mov ebx, 0 ; Restablece el contenido de EBX a cero

	pop ebx ; Desapila el elemento situado en el tope colocándolo en EBX (ESP aumenta 4 bytes)

	nop

	; SECCIÓN 2: MECÁNICA LIFO (ÚLTIMO EN ENTRAR, PRIMERO EN SALIR)
	mov eax, 10 ; Nivel ESP + 8
	push eax ; Inserta 10 en la pila (primer elemento colocado)

	mov eax, 20 ; Nivel ESP + 4
	push eax ; Inserta 20 en la pila (segundo elemento colocado)

	mov eax, 30 ; Nivel actual de ESP
	push eax ; Inserta 30 en la cima de la pila (desplazamientos de 4 bytes por cada DWORD apilado)

	nop

	pop eax ; Extrae el dato más reciente colocado en la cima: 30
	pop ebx ; Extrae el dato intermedio: 20
	pop ecx ; Extrae el primer elemento introducido: 10

	; SECCIÓN 3: PRESERVACIÓN Y RECUPERACIÓN DE ESTADO EN REGISTROS
	; Valores de prueba en EAX y EBX
	mov eax, 100 
	mov ebx, 200

	push eax ; Salvaguarda temporalmente el valor 100 dentro de la pila
	push ebx ; Salvaguarda temporalmente el valor 200 dentro de la pila

	mov eax, 999 ; Altera los valores de trabajo de EAX y EBX
	mov ebx, 666

	pop ebx ; Recupera el contenido previo de EBX (200) respetando el orden inverso de la pila
	pop eax ; Recupera el contenido previo de EAX (100)

	; SECCIÓN 4: INVOCACIÓN DE PROCEDIMIENTOS CON CALL Y RET
	
	mov eax, 111 ; Inicialización de valores para la subrutina
	mov ebx, 222

	call aumentarDiez ; Apila la dirección de regreso y salta a la rutina aumentarDiez

	nop

	exit

main ENDP ; Conclusión del procedimiento principal

aumentarDiez PROC ; Subrutina que añade 10 a EAX protegiendo el contenido de EBX
	push ebx ; Preserva el valor actual de EBX en la pila

	mov ebx, 10 ; Carga el sumando 10 en EBX

	add eax, ebx ; Adiciona EBX a EAX: 111 + 10

	pop ebx ; Restituye el valor inicial de EBX (222) desde la pila

	ret ; Desapila la dirección de retorno y devuelve la ejecución a la instrucción posterior a CALL
aumentarDiez ENDP
END main