; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: PRACTICA 2. CAPTURA Y DESPLEGADO DE MENSAJE
; Descripción: Solicita el nombre al usuario para guardarlo en memoria, presenta la cadena capturada y enseña el número de caracteres ingresados.
INCLUDE Irvine32.inc
.data
mensaje BYTE "Escribe tu nombre: ", 0 ; Prompt inicial que pide el nombre al usuario
nombre BYTE 30 DUP(0) ; Buffer de memoria apartado para guardar la cadena ingresada
caracteresEscritos BYTE "Caracteres escritos: ", 0 ; Etiqueta de texto finalizada en null para el conteo

.code
main PROC

; Muestra en pantalla la indicación para el usuario
 mov edx, OFFSET mensaje
 call WriteString

 mov edx, OFFSET nombre ; Puntero hacia el inicio del buffer receptor  
 mov ecx, SIZEOF nombre ; Capacidad máxima permitida en bytes

 call ReadString ; Captura el texto introducido desde el teclado (la longitud queda en EAX) 

 ; Presenta el texto guardado en el buffer
 mov edx, OFFSET nombre ; Apunta nuevamente a la dirección del texto almacenado
 call WriteString ; Imprime en consola la cadena recibida
 call Crlf ; Emite un retorno de carro y avance de línea
 
; Presenta la cuenta de caracteres capturados
 mov edx, OFFSET caracteresEscritos ; Puntero a la etiqueta de resumen de caracteres
 call WriteString
 call WriteDec ; Muestra en pantalla el total leído registrado en EAX como número decimal

 exit


main ENDP


END main