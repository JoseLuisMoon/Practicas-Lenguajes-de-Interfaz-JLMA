; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 8. Operaciones aritméticas
; Descripción: Demuestra el empleo práctico de las operaciones fundamentales ADD, SUB, MUL, IMUL, DIV e IDIV, analizando el comportamiento de las banderas CF y OF junto a la instrucción CDQ.
INCLUDE Irvine32.inc
.data
.code
main proc 
	; 1. ADICIÓN Y SUSTRACCIÓN (ADD Y SUB)
	; Carga inicial de operandos en los registros principales
	mov eax, 50 
	mov ebx, 20 

	add eax, ebx ; Incrementa EAX sumándole el contenido de EBX: 50 + 20
	sub eax, 15 ; Disminuye en 15 unidades el valor acumulado en EAX: 70 - 15

	nop ; Operación nula de pausa que facilita el seguimiento en el depurador

	; 2. BANDERA DE ACARREO (CF) EN CÁLCULO SIN SIGNO

	mov eax, 0 ; Pone a cero el acumulador EAX
	mov al, 255 ; Asigna 255 (FFh) en AL, tope de capacidad para un byte sin signo

	mov al, 1 ; Modifica el byte AL asignándole el valor 1

	nop


	; 3. BANDERA DE DESBORDAMIENTO (OF) EN OPERACIONES CON SIGNO
	mov eax, 0 ; Limpieza del registro EAX
	mov al, 127 ; Asigna 127 a AL, valor positivo máximo para 8 bits con signo

	add al, 1 ; Adiciona 1 a AL: 127 + 1
			  ; Sobrepasa el rango para números con signo [+127] activando el flag OF

	nop

	; 4. MULTIPLICACIÓN SIN SIGNO (MUL) AJUSTADA A 32 BITS
	; Asignación de factores en EAX y EBX
	mov eax, 25
	mov ebx, 3

	mul ebx ; Producto no firmado entre EAX y EBX: 25 * 3
			; El producto final queda almacenado en EAX

	nop

	; 5. MULTIPLICACIÓN CON SIGNO (IMUL) EN 32 BITS 

	mov eax, -5 ; Carga una cifra negativa con signo en EAX

	imul eax, eax, 3 ; Multiplicación con signo de EAX por 3: -5 * 3
					 ; Deposita el resultado resultante en EAX

	; 6. MULTIPLICACIÓN (MUL) CON DESBORDE A 64 BITS (EDX:EAX)

	mov eax, 65537
	mov ebx, 655537

	mul ebx ; Calcula el producto; al rebasar 32 bits, la parte alta se aloja en EDX y la baja en EAX
	
	nop

	; 7. DIVISIÓN ENTERA SIN SIGNO (DIV)
	mov eax, 125 ; Fija la porción inferior del dividendo
	mov edx, 0 ; Limpia EDX para configurar el dividendo completo de 64 bits en cero
	mov ebx, 12 ; Establece el divisor en EBX

	div ebx ; Divide EDX:EAX entre EBX; asigna el cociente a EAX y el residuo a EDX

	nop
	

	; 8. DIVISIÓN CON SIGNO (IDIV) CON OPERANDOS NEGATIVOS

	mov eax, -125 ; Carga el valor negativo a ser dividido en EAX
	cdq ; Propaga el bit de signo de EAX hacia EDX (llenándolo con FFFFFFFFh) para ajustar la división signada

	mov ebx, 12 ; Carga el divisor 12 en EBX

	idiv ebx ; Realiza la división con signo; el cociente resultante queda en EAX y el resto en EDX

	nop
	exit
main ENDP

END main