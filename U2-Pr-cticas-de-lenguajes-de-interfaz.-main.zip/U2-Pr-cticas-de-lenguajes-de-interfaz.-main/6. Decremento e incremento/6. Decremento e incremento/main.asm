; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 6. Decremento e incremento
; Descripción: Gestiona la autenticación de un usuario mediante una clave PIN con un límite de tres oportunidades, usando decrementos y saltos lógicos para autorizar o bloquear el acceso.
INCLUDE Irvine32.inc
.data
	; Cadenas empleadas en la interfaz de usuario durante la validación
	msgPIN BYTE "Ingrese el PIN: ", 0
	msgIntentos BYTE "Intentos restantes: ", 0
	msgError BYTE "PIN incorrecto.", 0
	msgAcceso BYTE "Acceso permitido", 0
	msgBloqueado BYTE "Autodestruccion comenzada...", 0

	pinCorrecto = 1234 ; Clave numérica válida predeterminada

.code
	main PROC
	mov ebx, 3 ; Asignación de 3 oportunidades máximas de acceso

intentar: ; Inicio del ciclo de verificación de clave
	; Petición y lectura de la clave ingresada
	mov edx, OFFSET msgPIN
	call WriteString
	call ReadInt

	cmp eax, pinCorrecto ; Confronta la clave tecleada frente al valor esperado
	je acceso ; Si la clave es acertada, procede a la sección de acceso

	mov edx, OFFSET msgError ; Carga la alerta de clave errónea
	call WriteString
	call Crlf

	dec ebx ; Reduce en una unidad el total de intentos disponibles

	jz bloqueado ; Si se agotan los intentos (EBX = 0), pasa a la etiqueta de bloqueo

	mov edx, OFFSET msgIntentos ; Despliega el texto de oportunidades restantes
	call WriteString

	mov eax, ebx
	call WriteDec ; Muestra en consola la cifra de oportunidades vigentes
	call Crlf

	jmp intentar ; Vuelve a solicitar el PIN para un nuevo intento

acceso: ; Rutina ejecutada cuando la autenticación resulta exitosa
	mov edx, OFFSET msgAcceso ; Despliega el aviso de entrada concedida
	call WriteString
	call crlf ; Salto de renglón
	jmp fin ; Dirige el flujo a la terminación del proceso

bloqueado:
	mov edx, OFFSET msgBloqueado ; Despliega el aviso de bloqueo del sistema
	call WriteString
	call Crlf ; Salto de renglón
	jmp fin ; Dirige el flujo a la terminación del proceso

fin: ; Punto de salida del programa
	exit
main ENDP

END main