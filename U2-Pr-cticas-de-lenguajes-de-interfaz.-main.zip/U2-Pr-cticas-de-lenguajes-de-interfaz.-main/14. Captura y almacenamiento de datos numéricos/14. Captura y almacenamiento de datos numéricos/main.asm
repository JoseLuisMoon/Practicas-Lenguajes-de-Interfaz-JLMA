; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 14. Captura y almacenamiento de datos numéricos.
; Descripción: Lee la cantidad de unidades como cadena de texto (1 a 99), valida los caracteres numéricos, los acumula en un valor entero, actualiza el inventario sumándolo a la existencia inicial y genera la cadena decimal de salida para su despliegue.
INCLUDE Irvine32.inc

.data

; Mensajes para la interacción en consola
msgIngresoDatos BYTE "Ingrese las unidades recibidas: ", 0
msgCadenaInvalida BYTE "El programa solo acepta cadenas entre 1 y 99.", 0dh, 0ah, 0
msgResultado BYTE "Unidades Actuales: ", 0

; Búfer donde ReadString captura la entrada en texto
bufferInput BYTE 10 DUP(0)

; Variables numéricas de almacenamiento
cantidadRecibida DWORD ?
existenciaInicial DWORD 25
existenciaActual DWORD ?

; Búfer para formatear la cadena de texto resultante
bufferOutput BYTE 12 DUP(0)

.code
main PROC

IngresarDatos:
	mov edx, OFFSET msgIngresoDatos ; Muestra la solicitud de captura
	call WriteString

	mov edx, OFFSET bufferInput ; Asigna a EDX la dirección del búfer de entrada
	mov ecx, 9 ; Límite de caracteres a leer
	call ReadString ; Captura el texto y coloca la longitud leída en EAX

	; Validación simple de la cantidad de caracteres leídos
	cmp eax, 2 ; Comprueba primero que no sobrepase 2 caracteres
	ja MostrarError ; Si tiene más de dos caracteres, salta a error

	cmp eax, 0 ; Comprueba que la entrada no esté vacía
	je MostrarError ; Si la longitud es cero, salta a error

	mov ecx, eax ; Configura el contador del ciclo con la longitud de la cadena
	mov esi, 0 ; Índice apuntando al inicio de la cadena
	mov edx, 0 ; EDX actuará como acumulador numérico en cero

ConvertirCadena:
	mov al, bufferInput[esi] ; Toma el carácter actual
	cmp al, '0' ; Verifica que no sea menor a '0'
	jb MostrarError
	cmp al, '9' ; Verifica que no sea mayor a '9'
	ja MostrarError

	sub al, '0' ; Convierte el código ASCII a dígito decimal (0 al 9)

	imul edx, edx, 10 ; Multiplica el acumulado por 10 para abrir espacio a las unidades
	add dl, al ; Suma el nuevo dígito al acumulador

	inc esi ; Avanza a la siguiente posición
	loop ConvertirCadena ; Repite para los caracteres restantes

	; Valida que el número resultante esté en el intervalo permitido [1, 99]
	cmp edx, 1
	jb MostrarError
	cmp edx, 99
	ja MostrarError

	mov cantidadRecibida, edx ; Guarda el valor numérico en la variable

	; Suma la cantidad recibida a la existencia base (25)
	mov eax, existenciaInicial
	add eax, cantidadRecibida
	mov existenciaActual, eax ; Guarda el nuevo inventario total

	mov edx, OFFSET msgResultado ; Muestra el encabezado del resultado
	call WriteString

	mov eax, existenciaActual ; Valor entero a convertir a texto
	mov edi, OFFSET bufferOutput ; Dirección del búfer receptor
	call ConvertirDecimalToString ; Convierte el número a cadena de caracteres

	mov edx, OFFSET bufferOutput ; Carga la dirección del texto generado
	call WriteString ; Imprime la existencia actual por pantalla
	call Crlf

	exit

MostrarError:
	mov edx, OFFSET msgCadenaInvalida ; Muestra el mensaje de error por formato o rango
	call WriteString
	jmp IngresarDatos ; Vuelve a solicitar el dato al usuario

main ENDP

ConvertirDecimalToString PROC ; Subrutina que convierte un entero en EAX a caracteres en [EDI]
	; Respalda los registros en la pila
	push eax
	push ebx
	push ecx
	push edx

	mov ecx, 0 ; Contador de dígitos extraídos
	mov ebx, 10 ; Divisor de base diez

ExtraerDigitos:
	mov edx, 0 ; Limpia EDX para la división
	div ebx ; Divide EDX:EAX entre 10 (cociente en EAX, residuo en EDX)
	add dl, '0' ; Convierte el residuo numérico a su carácter ASCII correspondiente
	push dx ; Apila el carácter para ordenar después
	inc ecx ; Cuenta un dígito más
	cmp eax, 0 ; Comprueba si el cociente llegó a cero
	jne ExtraerDigitos ; Si todavía quedan dígitos, continúa dividiendo

GuardarEnBuffer:
	pop dx ; Extrae de la pila en orden secuencial inverso
	mov [edi], dl ; Asienta el carácter en el búfer
	inc edi ; Avanza el apuntador
	loop GuardarEnBuffer ; Repite para todos los dígitos obtenidos

	mov byte ptr [edi], 0 ; Agrega el terminador nulo al final de la cadena

	; Restaura los registros de la pila
	pop edx
	pop ecx
	pop ebx
	pop eax
	ret ; Regresa al procedimiento principal
ConvertirDecimalToString ENDP

END main
