; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 6.1. Control de Estacionamiento
; Descripción: Controla el aforo de un estacionamiento registrando accesos (1) y salidas (2) mediante incrementos y decrementos, terminando cuando se alcanza el tope de 10 unidades.
INCLUDE Irvine32.inc

.data
    ; Mensajes para la interacción con el usuario en consola
    msgInicial BYTE "Ingrese 1 (entra) o 2 (sale): ", 0
    msgEntrada BYTE "Un vehiculo ha ingresado", 0
    msgSalida BYTE "Un vehiculo ha salido", 0
    msgFull BYTE "El estacionamiento esta lleno", 0
    msgInvalido BYTE "Opcion no valida. Intente de nuevo.", 0

    limiteEstacionamiento = 10 ; Capacidad máxima permitida de vehículos

.code
main PROC
    mov ebx, 0 ; EBX funciona como contador de vehículos dentro del estacionamiento

FlujoEstacionamiento:
    call Crlf 
    mov edx, OFFSET msgInicial ; Solicita al usuario seleccionar la operación
    call WriteString
    call ReadInt ; Captura la opción tecleada en el registro EAX

    ; Se verifica primero la opción de salida (2) y después la de entrada (1)
    cmp eax, 2
    je vehiculoSale

    cmp eax, 1
    je vehiculoEntra

    ; Si el valor no coincide con 1 ni con 2, se reporta como entrada inválida
    mov edx, OFFSET msgInvalido
    call WriteString
    call Crlf
    jmp FlujoEstacionamiento ; Vuelve al inicio del menú

vehiculoEntra:    
    inc ebx ; Aumenta en 1 el número de carros en el estacionamiento
    mov edx, OFFSET msgEntrada ; Notifica que un vehículo ingresó
    call WriteString
    call Crlf
    
    cmp ebx, limiteEstacionamiento ; Comprueba si se alcanzó el cupo máximo de 10
    je estLleno ; Si se alcanzaron los 10 vehículos, procede a reportar lleno y terminar

    jmp FlujoEstacionamiento ; Si aún hay espacio, continúa pidiendo operaciones

vehiculoSale:
    ; Verifica que haya al menos un auto adentro antes de decrementar
    cmp ebx, 0
    jle noHayAutos ; Si no hay autos (EBX <= 0), evita decrementar y vuelve a pedir opción

    dec ebx ; Resta un vehículo del contador
    mov edx, OFFSET msgSalida ; Notifica que un vehículo salió
    call WriteString
    call Crlf

noHayAutos:
    jmp FlujoEstacionamiento ; Regresa a solicitar la siguiente opción

estLleno:
    call Crlf
    mov edx, OFFSET msgFull ; Despliega el aviso de estacionamiento lleno
    call WriteString
    call Crlf

    exit
main ENDP

END main