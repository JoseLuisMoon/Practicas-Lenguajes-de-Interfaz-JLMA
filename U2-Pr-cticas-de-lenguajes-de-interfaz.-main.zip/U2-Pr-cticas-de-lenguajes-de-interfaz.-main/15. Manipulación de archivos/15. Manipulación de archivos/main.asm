; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 15. Manipulación de archivos
; Descripción: Genera en disco el archivo de texto "Inventario.txt", escribe en su contenido la cadena "125" y efectúa el cierre controlado del recurso con validación de estados y reporte de éxito o falla.
INCLUDE Irvine32.inc

.data 

nombreArchivo BYTE "Inventario.txt", 0 ; Nombre del archivo que será generado en disco
texto BYTE "125", 0 ; Información textual a almacenar dentro del archivo
archivoHandle DWORD ? ; Variable para almacenar el manipulador (handle) del archivo del sistema operativo

; Notificaciones para notificar el desenlace del proceso
mensajeExito BYTE "Archivo guardado correctamente",0
mensajeError BYTE "No se pudo guardar el archivo", 0

.code
main PROC

; 1. Creación del archivo de texto
mov edx, OFFSET nombreArchivo ; Pasa en EDX el puntero a la ruta o nombre del archivo
call CreateOutputFile ; Solicita al SO crear el fichero; el descriptor devuelto queda en EAX

cmp eax, INVALID_HANDLE_VALUE ; Verifica si la creación resultó fallida
je error ; Si no se pudo generar el archivo, bifurca al tratamiento de errores

mov archivoHandle, eax ; Preserva el identificador válido en memoria

; 2. Registro de datos en el archivo
mov eax, archivoHandle ; Suministra el identificador del archivo en EAX
mov edx, OFFSET texto ; Pasa la dirección de los datos a grabar en EDX
mov ecx, SIZEOF texto-1 ; Delimita los bytes a escribir sin considerar el carácter nulo final
call WriteToFile ; Envía los datos al archivo; devuelve la cantidad de bytes transferidos en EAX

jc errorEscritura ; Si la bandera de acarreo (CF) se activa, hubo anomalía en la escritura

cmp eax, SIZEOF texto-1 ; Contrasta los bytes efectivamente grabados con el volumen requerido
jne errorEscritura ; Transfiere al manejo de error si los bytes difieren

; 3. Liberación y cierre del archivo
mov eax, archivoHandle ; Carga el descriptor del archivo en EAX
call CloseFile ; Clausura el enlace del archivo liberando sus recursos

test eax, eax ; Examina mediante TEST si la operación de cierre retornó cero (fallo)

jz error ; Pasa a error si la respuesta del sistema operativo fue nula

mov edx, OFFSET mensajeExito ; Notifica la culminación satisfactoria de la operación
call WriteString
jmp fin ; Transfiere a la salida habiendo concluido de forma correcta

errorEscritura: ; Tratamiento de fallo durante la grabación de datos
	mov eax, archivoHandle ; Rescata el identificador del archivo
	call CloseFile ; Cierra el archivo abierto para prevenir fugas de memoria

error: ; Despliegue de alerta de error en la operación de archivos
	mov edx, OFFSET mensajeError ; Carga la alerta de falla al usuario
	call WriteString

fin: ; Conclusión del procedimiento principal
	exit
main ENDP

END main