; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 4.1. Mayor, menor o igual con entrada del usuario.
; Descripción: Solicita dos números enteros al usuario y los compara mediante CMP, empleando saltos condicionales para determinar si son iguales, menor o mayor.

INCLUDE Irvine32.inc

.data
; Cadenas de texto para solicitar los números de entrada
msgIngresar1 BYTE "Ingresa el primer valor: ", 0
msgIngresar2 BYTE "Ingresa el segundo valor: ", 0
; Cadenas de texto para desplegar el dictamen de la comparación
msgMayor   BYTE "El primer numero es mayor.", 0
msgMenor   BYTE "El primer numero es menor.", 0
msgIguales BYTE "Los numeros son iguales.", 0

.code
main PROC

    mov edx, OFFSET msgIngresar1 ; Presenta la solicitud del primer entero
    call WriteString 
    call ReadInt ; Captura el entero tecleado y lo almacena en EAX
    mov ecx, eax ; Respalda temporalmente el primer dato en ECX antes de la siguiente lectura

    mov edx, OFFSET msgIngresar2 ; Presenta la solicitud del segundo entero
    call WriteString 
    call ReadInt ; Captura el segundo dato numérico en EAX
    mov ebx, eax ; Traslada el segundo valor a EBX para confrontarlo
    
    mov eax, ecx ; Recupera el primer número en EAX para ejecutar la comparación

    cmp eax, ebx ; Compara el primer número (EAX) con el segundo (EBX)

    je iguales ; Si ambos valores coinciden, salta directamente a la etiqueta 'iguales'
    jl menor ; Si el primer número es más chico que el segundo, salta a 'menor'

    ; Si no resultó igual ni menor, significa que el primer número es mayor
    mov edx, OFFSET msgMayor ; Carga el mensaje de primer número mayor
    call WriteString
    jmp fin ; Brinca a la sección de salida para terminar

iguales:
    mov edx, OFFSET msgIguales ; Muestra el mensaje de que ambos números son idénticos
    call WriteString
    jmp fin

menor:
    mov edx, OFFSET msgMenor ; Muestra el mensaje de que el primer número es menor
    call WriteString

fin: 
    call Crlf ; Salto de línea estético
    exit

main ENDP
END main