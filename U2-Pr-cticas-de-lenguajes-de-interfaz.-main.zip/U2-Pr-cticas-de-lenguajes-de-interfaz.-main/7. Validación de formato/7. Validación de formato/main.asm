; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 7. Validación de formato de cadena
; Descripción: Solicita una cadena con el formato de 3 letras mayúsculas, un guion y 3 dígitos, validando primero su longitud, luego el separador y finalmente los caracteres alfabéticos y numéricos.

INCLUDE Irvine32.inc

.data
    msgInicio BYTE "Ingrese una cadena: ", 0
    msgLongitud BYTE "La longitud de la cadena no es de 7 caracteres.", 0
    msgLetras BYTE "La cadena no cumple con la cantidad de 3 letras mayusculas al inicio.", 0
    msgSeparador BYTE "La cadena no cumple con el formato de un separador en la posicion 4.", 0
    msgDigitos BYTE "La cadena no cumple con la cantidad de 3 digitos al final.", 0
    msgCadenaValida BYTE "La cadena cumple con el formato deseado.", 0

    buffer BYTE 20 DUP(0) ; Búfer para almacenar la entrada del usuario

.code
main PROC

solicitarCadena:
    call Crlf ; Salto de línea estético en cada intento
    
    mov edx, OFFSET msgInicio ; Solicita la cadena al usuario
    call WriteString

    mov edx, OFFSET buffer ; Dirección destino del búfer de lectura
    mov ecx, SIZEOF buffer ; Límite de bytes permitidos para evitar desbordes
    call ReadString ; Captura el texto y coloca la longitud en EAX

    ; Paso 1: Validar que la longitud total sea exactamente de 7 caracteres
    cmp eax, 7
    jne longitudInvalida ; Si la longitud difiere de 7, salta a reportar error

    ; Paso 2: Validar de inmediato el carácter separador central (posición índice 3)
    mov al, buffer[3]
    cmp al, '-' ; Comprueba si el cuarto carácter es un guion
    jne separadorInvalido ; Si no es guion, salta a error de separador

    ; Paso 3: Validar que los primeros 3 caracteres correspondan a letras mayúsculas ('A'-'Z')
    mov esi, 0 ; Índice inicial en la posición 0
    mov ecx, 3 ; 3 repeticiones para revisar los índices 0, 1 y 2

corroborarLetras:
    mov al, buffer[esi] ; Extrae el carácter actual
    cmp al, 'A' ; Límite inferior 'A'
    jb letrasInvalidas ; Si es menor al código de 'A', es inválido
    cmp al, 'Z' ; Límite superior 'Z'
    ja letrasInvalidas ; Si es mayor al código de 'Z', es inválido

    inc esi ; Pasa al siguiente carácter
    loop corroborarLetras ; Decrementa ECX y repite el bucle

    ; Paso 4: Validar que los últimos 3 caracteres sean dígitos numéricos ('0'-'9')
    mov esi, 4 ; Índice inicial para los dígitos (índices 4, 5 y 6)
    mov ecx, 3 ; 3 repeticiones

cicloDigitos:
    mov al, buffer[esi] ; Lee el dígito en la posición actual
    cmp al, '0' ; Límite inferior '0'
    jb digitosInvalidos ; Si es menor al código de '0', es inválido
    cmp al, '9' ; Límite superior '9'
    ja digitosInvalidos ; Si es mayor al código de '9', es inválido

    inc esi ; Avanza a la siguiente posición
    loop cicloDigitos ; Decrementa ECX y repite el bucle

    ; Si pasó todas las pruebas con éxito, se muestra el mensaje de aprobación
    mov edx, OFFSET msgCadenaValida
    call WriteString
    call Crlf
    jmp fin ; Finaliza el programa correctamente

; SECCIÓN DE MENSAJES DE ERROR
longitudInvalida:
    mov edx, OFFSET msgLongitud
    call WriteString
    call Crlf
    jmp solicitarCadena ; Vuelve a solicitar la cadena

separadorInvalido:
    mov edx, OFFSET msgSeparador
    call WriteString
    call Crlf
    jmp solicitarCadena

letrasInvalidas:
    mov edx, OFFSET msgLetras
    call WriteString
    call Crlf
    jmp solicitarCadena

digitosInvalidos:
    mov edx, OFFSET msgDigitos
    call WriteString
    call Crlf
    jmp solicitarCadena

fin:
    exit
main ENDP
END main