; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: Práctica 11. Operaciones lógicas
; Descripción: Ejemplifica el filtrado, encendido, alternancia y consulta de bits mediante las operaciones lógicas a nivel de bit AND, OR, XOR y TEST simulando estados de un equipo y su alarma.
INCLUDE Irvine32.inc 

.data 
    ; Cadenas para reportar el encendido o apagado del sistema de alarma
    msgEncendida BYTE "alarma encendida", 0
    msgApagada   BYTE "alarma apagada", 0 

.code 
main PROC

    ; Indicadores de estado del sistema:
    ; Bit 0 - Encendido de la computadora (0 = Apagada, 1 = Encendida)
    ; Bit 1 - Alarma activa
    ; Bit 2 - Conexión a red activa

    ; 1 - INSTRUCCIÓN AND: Aislamiento y comprobación del bit de alarma
    mov eax, 0 ; Restablece a cero el registro EAX
    mov al, 00000111b ; Asigna una máscara de prueba con varios bits activos
    and al, 00000010b ; Aplica máscara con AND para conservar exclusivamente el bit 1
    
    call WriteBin ; Despliega el formato binario del resultado
    call Crlf ; Retorno de carro y avance de renglón
    nop ; Instrucción nula para pausar e inspeccionar registros

    ; 2 - INSTRUCCIÓN OR: Activación selectiva de la alarma
    mov eax, 0 ; Borra el contenido de EAX
    mov al, 00000101b ; Estado base (equipo encendido y conectado, alarma en cero)
    or al, 00000010b ; Aplica máscara OR para poner en 1 el bit 1 preservando los demás
    
    call WriteBin ; Muestra el resultado binario
    call Crlf 
    nop 

    ; 3 - INSTRUCCIÓN XOR: Conmutación (toggle) del estado de la computadora
    ; XOR conmuta los bits correspondientes donde la máscara contenga un 1
    mov eax, 0 ; Limpia el registro
    mov al, 00000101b ; Asigna el estado inicial donde el bit 0 vale 1
    
    xor al, 00000001b ; Alterna el bit 0 a 0 (apaga el equipo)
    call WriteBin ; Muestra el nuevo estado
    call Crlf
    
    xor al, 00000001b ; Vuelve a conmutar el bit 0 devolviéndolo a 1 (reenciende el equipo)
    call WriteBin ; Muestra el estado restaurado
    call Crlf
    nop 

    ; 4 - INSTRUCCIÓN TEST: Inspección no destructiva del estado de la alarma
    ; TEST aplica internamente un AND modificando únicamente las banderas sin alterar AL
    mov al, 00000101b ; Carga el estado inicial
    test al, 00000010b ; Examina el bit 1 mediante una máscara binaria
    
    jnz alarma_encendida ; Brinca si el bit evaluado no fue cero (alarma encendida)
    
    ; Rama correspondiente a alarma inactiva
    mov edx, OFFSET msgApagada ; Carga la dirección del mensaje de alarma apagada
    call WriteString ; Imprime en consola el mensaje
    call Crlf 
    jmp fin ; Bifurcación incondicional al término del programa

alarma_encendida: ; Rama ejecutada cuando la alarma permanece activa
    mov edx, OFFSET msgEncendida ; Notificación de alarma activa
    call WriteString 
    call Crlf 

fin:
    exit 

main ENDP 

END main