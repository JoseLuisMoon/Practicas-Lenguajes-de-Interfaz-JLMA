; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: Práctica 4. Saltos
; Descripción: Evalúa la relación entre dos cantidades enteras con CMP y bifurca el flujo con saltos JE y JMP para notificar igualdad o discrepancia.

INCLUDE Irvine32.inc
.data
; Cadenas para reportar si los valores coinciden o discrepan
msgIguales Byte "Los numeros son iguales", 0 
msgDiferentes Byte "Los numeros son diferentes", 0

.code
main PROC

	; Carga inicial de dos valores en EAX y EBX para su verificación
	mov eax, 10
	mov ebx, 10

	cmp eax, ebx ; Contrasta ambos operandos mediante una resta lógica interna (EAX - EBX)
	
	je iguales ; Brinca a la sección 'iguales' si la bandera ZF indica equivalencia

	mov edx, OFFSET msgDiferentes ; Apunta al texto informativo de valores distintos
	call WriteString

	jmp fin ; Salto directo sin condición hacia la terminación

	iguales: ; Bloque de ejecución cuando ambos números son idénticos
		mov edx, OFFSET msgIguales ; Prepara el mensaje de números iguales para despliegue
		call WriteString
	
	fin:
		call Crlf ; Emite un retorno de carro con salto de línea
 exit
main ENDP
END main