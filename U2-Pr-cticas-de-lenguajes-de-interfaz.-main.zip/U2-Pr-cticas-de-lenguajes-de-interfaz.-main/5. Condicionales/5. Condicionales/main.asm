; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: 5. Condicionales
; Descripción: Implementa y contrasta los ciclos repetitivos tipo WHILE y DO-WHILE imprimiendo secuencias numéricas del 1 al 100 en un solo programa.
INCLUDE Irvine32.inc
.data
    ; Mensajes descriptivos para encabezar cada sección de iteración
    msgWhile BYTE "Ciclo While", 0 
    msgDoWhile BYTE "Ciclo Do While", 0
.code
main PROC

    mov edx, OFFSET msgWhile ; Presenta el título del bucle tipo While
    call WriteString
    call Crlf

    mov ebx, 1 ; Inicializa la variable de control del bucle en 1

cicloWhile:
    cmp ebx, 100 ; Comprueba si se alcanzó el límite superior

    jg finWhile ; Sale del ciclo si el contador sobrepasa el valor 100
    
    mov eax, ebx
    call WriteDec ; Imprime el valor numérico actual presente en EAX
    call Crlf ; Emite un salto de renglón

    inc ebx ; Incrementa la cuenta de EBX en una unidad
    jmp cicloWhile ; Itera nuevamente al inicio del bucle While
finWhile:
    call Crlf ; Salto de línea estético entre bloques

    mov edx, OFFSET msgDoWhile ; Despliega el encabezado correspondiente al ciclo Do-While
    call WriteString
    call Crlf

    mov ebx, 1 ; Restablece el valor del contador para el nuevo bucle

cicloDoWhile:

    mov eax, ebx
    call WriteDec ; Muestra en pantalla el contenido numérico de EAX
    call Crlf

    inc ebx ; Aumenta en uno el valor de EBX
    cmp ebx, 100 ; Evalúa la condición de permanencia al pie del bloque

    jle cicloDoWhile ; Repite el bucle Do-While mientras EBX no exceda 100

    exit
main ENDP

END main