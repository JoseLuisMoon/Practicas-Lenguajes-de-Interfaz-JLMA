; Materia: Lenguajes de Interfaz
; Alumno: Jorge Emilio López Payán
; Horario: 10-11
; Docente: Dr. José Luis Medina Jiménez
; Práctica: Práctica 1. Ciclos numéricos
; Descripción: Despliega de forma descendente los números del 5 al 1 empleando la instrucción loop.

INCLUDE Irvine32.inc

.data
.code
main PROC
    mov ecx, 5 ; Asignar el valor inicial al registro ECX como contador para la instrucción loop
    
ciclo:
    mov eax, ecx ; Transferir el contador actual de ECX al acumulador EAX
    
    call WriteDec ; Mostrar en consola el número decimal contenido en EAX
    call Crlf ; Generar un salto de línea
    loop ciclo ; Decrementar ECX de forma automática y reiterar el bucle mientras no llegue a cero.
    
    exit
main ENDP

END main